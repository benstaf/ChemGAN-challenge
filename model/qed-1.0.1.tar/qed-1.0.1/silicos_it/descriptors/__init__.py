__all__ = ["qed"]
